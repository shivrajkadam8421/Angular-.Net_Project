﻿using System;
using System.Collections.Generic;

namespace BookCart.Models
{
    public partial class UserType
    {
        public int UserTypeId { get; set; }
        public string UserTypeName { get; set; }
    }
}
