export enum UserType {
    admin = 1,
    user = 2
}
